package com.parkease.CustomException;

public class ResourceNotFoundException extends RuntimeException {
	ResourceNotFoundException(String msg){
		super(msg);
	}
}
