package com.parkease.eums;

public enum PaymentMethod {
	CREDIT_CARD, DEBIT_CARD, UPI
}
