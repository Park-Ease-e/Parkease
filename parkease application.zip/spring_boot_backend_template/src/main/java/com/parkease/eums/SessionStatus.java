package com.parkease.eums;

public enum SessionStatus {
	ACTIVE, COMPLETED
}
