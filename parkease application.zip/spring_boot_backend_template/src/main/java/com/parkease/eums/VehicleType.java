package com.parkease.eums;

public enum VehicleType {
   HATCHBACK, SEDAN, SUV, WAGON
}
