package com.parkease.eums;

public enum ReservationStatus {
	Completed, CONFIRMED, CANCELLED
}
