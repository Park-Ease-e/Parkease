package com.parkease.eums;

public enum Role {
	ADMIN, Customer , Employee
}
