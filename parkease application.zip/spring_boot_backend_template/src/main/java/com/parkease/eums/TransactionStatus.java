package com.parkease.eums;

public enum TransactionStatus {
	SUCCESS, FAILURE, PENDING
}
