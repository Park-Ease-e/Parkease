package com.parkease.services;

public interface ReviewService {

}
