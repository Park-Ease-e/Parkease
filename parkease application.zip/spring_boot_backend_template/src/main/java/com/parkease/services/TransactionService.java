package com.parkease.services;

public interface TransactionService {

}
