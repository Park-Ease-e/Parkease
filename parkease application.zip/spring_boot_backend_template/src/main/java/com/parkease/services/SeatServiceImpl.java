package com.parkease.services;

public class SeatServiceImpl {

}
