package com.parkease.services;

public class VehicleServiceImpl {

}
